/**
	*
  */ 
	
#include "main.h" 
double adata,limit=1.70;
/**
  * @brief  ������
  * @param  ��  
  * @retval ��
  */

u8 test_io1;
u8 test_io5;
int main(void)
{	
	/* LED �˿ڳ�ʼ�� */
	SystemInit();
	LED_GPIO_Config();	 
	EXTI_Key_Config();
  SysTick_Config(SystemCoreClock/100000);
  LED_AllON();
	LED_AllOFF();
	
	/*GPIO_InitTypeDef GPIO_InitStructure; 
	RCC_APB2PeriphClockCmd(KEY1_INT_GPIO_CLK,ENABLE);
  GPIO_InitStructure.GPIO_Pin = KEY1_INT_GPIO_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
  GPIO_Init(KEY1_INT_GPIO_PORT, &GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(KEY3_INT_GPIO_CLK,ENABLE);
  GPIO_InitStructure.GPIO_Pin = KEY3_INT_GPIO_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
  GPIO_Init(KEY5_INT_GPIO_PORT, &GPIO_InitStructure);*/
	
	
	while(1)
	{
		//LED_AllON();
		//LED_AllOFF();
		LED_Rand();
		
		/*if(GPIO_ReadInputDataBit(KEY1_INT_GPIO_PORT,KEY1_INT_GPIO_PIN)!=0)
		{
			test_io1=1;
		}
		if(GPIO_ReadInputDataBit(KEY3_INT_GPIO_PORT,KEY3_INT_GPIO_PIN)!=0)
		{
			test_io5=1;
		}
		*/
		
	}
}
void SysTick_Handler(void)
{
	TimingDelay_Decrement();	
}
void Delay(__IO uint32_t nCount)	 //�򵥵���ʱ����
{
	for(; nCount != 0; nCount--);
}
/*********************************************END OF FILE**********************/
