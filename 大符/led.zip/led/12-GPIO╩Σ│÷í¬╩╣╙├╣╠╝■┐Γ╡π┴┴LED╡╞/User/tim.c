#include "main.h"

/*1ms��ȷ��ʱ*/
u16 arr=10;
void Tim_Config(void)
{
	
	TIM_TimeBaseInitTypeDef tim_init;
	
	TIM_DeInit(TIM3);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	tim_init.TIM_Period=7200-1;
	tim_init.TIM_Prescaler=arr-1;
	tim_init.TIM_CounterMode=TIM_CounterMode_Up;
	tim_init.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInit(TIM3,&tim_init);
	
	TIM_ClearFlag(TIM3,TIM_FLAG_Update);
	TIM_Cmd(TIM3,ENABLE);
	while(TIM_GetFlagStatus(TIM3,TIM_FLAG_Update)!=SET);
	TIM_ClearFlag(TIM3,TIM_FLAG_Update);
	TIM_Cmd(TIM3,DISABLE);
}

/***led��ʱ����**/
extern volatile u8 temp[6];				//�����־λ
extern volatile u8 Led_Status[6];	//װ�װ�״̬λ
void Delay_Ms(u32 time,u8 led_num)
{
	u8 num,i;
	while(time--)
	{
		Tim_Config();
		if((temp[led_num]!=0)&&(Led_Status[led_num]!=0))
			return;
	}
	
	for(num=1;num<6;num++)
	{
		if((Led_Status[num]!=0)&&(temp[num]==0))
		{
			for(i=1;i<6;i++)
			{
				temp[i]=0;
				Led_Status[i]=0;
			}
			LED_AllOFF();
			break;
		}
	}
	return;
}