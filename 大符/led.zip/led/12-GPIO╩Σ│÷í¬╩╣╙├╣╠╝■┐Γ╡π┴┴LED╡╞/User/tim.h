#ifndef __TIM_H
#define __TIM_H
#include "stm32f10x.h"

void Tim_Config(void);
void Delay_Ms(u32 time,u8 led_num);
#endif